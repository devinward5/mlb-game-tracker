export default function Home() {
  return (
    <main className="p-8">
      <h1 className="text-2xl font-bold">MLB Game Tracker</h1>
      <p className="mt-4">Welcome! Your app is set up and ready to expand.</p>
    </main>
  );
}
